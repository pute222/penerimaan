<?php
defined('BASEPATH') OR die('No direct script access allowed!');

class registrasi_model extends CI_Model
{
    public function get_all()
    {
        $result = $this->db->get('registrasi');
        return $result->result();
    }
